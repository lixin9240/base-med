# laravel框架代码规范

## 路由写法：

~~~php
// 命名参数，顺序可以调换，不影响结果
Route::get(action: [UserController::class, 'index'], uri: '/users');
// 和下面效果完全一样
Route::get(uri: '/users', action: [UserController::class, 'index']);
~~~

**核心原则**

```
Request：
只做参数验证

Controller：
只做请求接收与结果返回

Service：
只做业务逻辑

Model：
只做数据访问

事务统一在Service

日志统一在Service

缓存统一在Service

Controller禁止直接操作数据库

Model禁止编写业务逻辑
```

### 

系统采用 Laravel 分层架构开发，统一划分为：

```
Request    ↓Controller    ↓Service    ↓Model    ↓Database
```

------

## 1. Request层（参数验证层）

**职责**

负责：

-  参数合法性验证 
-  参数格式转换 
-  参数默认值处理 
-  权限预检查（可选） 

**禁止**

禁止在 Request 中：

```
User::query();DB::table();Log::info();Redis::get();
```

禁止：

```
public function rules(){    User::where(...); // 禁止数据库业务查询}
```

**正确示例**

```
class CustomerDetailRequest extends FormRequest{    public function rules(): array    {        return [            'id' => [                'required',                'integer',                'min:1',                Rule::exists('customers', 'id')            ]        ];    }    public function messages(): array    {        return [            'id.required' => '客户ID不能为空',            'id.exists' => '客户不存在'        ];    }}
```

------

## 2. Controller层（接口控制层）

**职责**

负责：

-  接收请求 
-  调用 Service 
-  返回统一结果 

**禁止**：

1.

```
public function detail(Request $request){    $customer = Customer::find($request->id);    return response()->json($customer);}
```

2.

```
DB::transaction(function () {});
```

3.

```
Redis::set();
```

4.

```
复杂业务逻辑
```

**Controller原则**

Controller代码原则：

```
控制器代码尽量控制在50行以内
```

Controller只负责：

```
接收↓调用↓返回
```

**正确示例**

```
class CustomerController extends Controller{    public function detail(        CustomerDetailRequest $request    ): JsonResponse {        $data = $this->customerService->detail(            $request->validated('id')        );        return Result::success(            '获取成功',            $data        );    }}
```

------

## 3. Service层（业务逻辑层）

**职责**

所有业务逻辑必须写在 Service。

包括：

```
业务计算业务校验事务控制状态流转日志记录缓存处理调用第三方接口
```

**Service是整个系统核心**

例如：

```
public function createOrder(array $data): Order{    return DB::transaction(function () use ($data) {        $customer = Customer::query()            ->lockForUpdate()            ->findOrFail($data['customer_id']);        if ($customer->balance < $data['amount']) {            throw new BusinessException(                ResponseCode::BALANCE_NOT_ENOUGH            );        }        $order = Order::create($data);        $customer->decrement(            'balance',            $data['amount']        );        Log::channel('business')->info(            '订单创建成功',            [                'order_id' => $order->id            ]        );        return $order;    });}
```

------

## 4. Model层（数据访问层）



负责：

```
数据库表映射关联关系查询作用域数据转换
```

### 

禁止：

```
class Customer extends Model{    public function createOrder()    {        // 业务逻辑    }}
```

禁止：

```
public function calculateCommission(){}
```

禁止：

```
public function sendSms(){}
```

**正确示例**

```
class Customer extends Model{    protected $table = 'customers';    protected $casts = [        'id' => 'integer',        'status' => 'integer',        'created_at' => 'datetime'    ];    public function orders()    {        return $this->hasMany(            Order::class,            'customer_id'        );    }    public function scopeEnabled($query)    {        return $query->where(            'status',            1        );    }}
```

------

## 5. 分层调用规范

**允许调用**

```
Controller    ↓Service    ↓Model
```

**禁止跨层调用**

禁止：

```
Controller    ↓Model
```

例如：

```
public function detail(){    Customer::find(1);}
```

禁止。

------

禁止：

```
Model    ↓Service
```

例如：

```
class Customer extends Model{    public function test()    {        app(CustomerService::class)            ->detail(1);    }}
```

禁止。

------

禁止：

```
Service A    ↓Controller B
```

例如：

```
app(CustomerController::class)    ->detail();
```

